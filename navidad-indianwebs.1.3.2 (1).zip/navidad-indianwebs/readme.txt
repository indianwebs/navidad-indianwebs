﻿=== Plugin Navidad IndianWebs ===
Contributors: CristoH
Tags: Plugin Navidad IndianWebs, Navidad, Snowfall, Christmas, IndianWebs, indianwebs, plugin
Requires at least: 4.0
Tested up to: 5.5.1
Stable tag: 1.3.1
License: GPLv2 or later

Pon un mensaje de navidad en tu web y un efecto de nieve en unos sencillos pasos.

== Description ==

Plugin Navidad IndianWebs v1.2

Pon un mensaje de navidad en tu web y un efecto de nieve en unos sencillos pasos.

Con más de 2500 clientes satisfechos en creación y mantenimiento de webs, intranets, y apps en internet. Las páginas web y tiendas virtuales, avalan nuestra trayectoria, a lo largo de 19 años de actividad, desde 1996.

IndianWebs es un proveedor de soluciones web, ofreciendo desde servicios de páginas web, promoción, mantenimiento, consultoría y programación.


== Installation ==

1. Subir 'plugin-navidad-indianwebs' a la ruta '/wp-content/plugins/'
2. Activar el plugin desde el menu de Plugins de WordPress.
3. Click en el menu "Navidad IndianWebs 
4. Elige las opciones del configurador.
5. Click en el botón de guardar.


== Screenshots  ==

1. screenshot-1.png

== Changelog ==

= 1.3 =

*Nuevas opciones: Ahora puedes configurar valores de los copos de nieve.

= 1.2 =

*Revisión compatible con Wordpress 5.0.

= 1.1 =

*Cambio en el efecto de nieve.

= 1.0 =

*Creación del plugin.

