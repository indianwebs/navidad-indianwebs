function cerrar() {
    var tarjeta = document.getElementsByClassName("tarjeta");
	for(var i=0;i<tarjeta.length;i++){
		tarjeta[i].style.display = "none";
	}
}